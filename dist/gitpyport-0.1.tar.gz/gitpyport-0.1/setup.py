from setuptools import setup, find_packages

setup(
	name='gitpyport',
    version='0.1',
    description='This module will help to import github python packages as python module',
    url='',
    author='Dipnarayan Das',
    author_email='dipnarayan.das35@gmail.com',
    license='MIT',
   	packages=['gitpyport',''],
   	include_package_data=True,
    zip_safe=False
)
